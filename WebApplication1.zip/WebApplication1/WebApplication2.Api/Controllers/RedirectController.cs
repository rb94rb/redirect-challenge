using Microsoft.AspNetCore.Mvc;
using WebApplication1;

namespace WebApplication2.Api.Controllers
{
    [ApiController]
    [Route("[controller]/api/[action]")]
    public class RedirectController : ControllerBase
    {
        private readonly ILogger<RedirectController> _logger;

        public RedirectController(ILogger<RedirectController> logger)
        {
            _logger = logger;
        }

        [HttpGet(Name = "GetRedirectUrls")]
        public IEnumerable<RedirectEntry> GetRedirectUrls()
        {
            return new List<RedirectEntry>() {
                new RedirectEntry() {
                    RedirectUrl = "/campaignA",
                    TargetUrl = "/campaigns/targetcampaign",
                    RedirectType = 302,
                    UseRelative = false
                },
                new RedirectEntry() {
                    RedirectUrl = "/campaignB",
                    TargetUrl = "/campaigns/targetcampaign/channelB",
                    RedirectType = 302,
                    UseRelative = false
                },
                new RedirectEntry() {
                    RedirectUrl = "/product-directory",
                    TargetUrl = "/products",
                    RedirectType = 301,
                    UseRelative = true
                }

            };

        }
    }
}