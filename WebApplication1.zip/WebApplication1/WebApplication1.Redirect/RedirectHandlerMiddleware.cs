﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;

namespace WebApplication1
{

    public class RedirectHandlerMiddleware : IDisposable
    {
        private readonly RequestDelegate _next;
        private readonly RedirectHandlerOptions _options;
        private readonly ILogger<RedirectHandlerMiddleware> _logger;        
        private readonly ConcurrentDictionary<string, RedirectEntry> _cache;        
        private Timer _timer;

        public RedirectHandlerMiddleware(RequestDelegate next, IOptions<RedirectHandlerOptions> options, ILogger<RedirectHandlerMiddleware> logger)
        {
            _next = next;
            _options = options.Value;
            _logger = logger;
            _cache = new ConcurrentDictionary<string, RedirectEntry>();            
            SetupCacheTimer();
        }

        private void SetupCacheTimer()
        {
            var cacheTimeoutMs = ((int)_options.CacheDuration.TotalMilliseconds);
            _timer = new Timer(HandleTimerCallback, null, 0, cacheTimeoutMs);
        }

        private async void HandleTimerCallback(object state)
        {
            if (_timer == null) return;
            await RefreshCacheAsync();
        }

        public async Task Invoke(HttpContext context)
        {
            RedirectEntry entry;

            var requestPath = context.Request.Path;
            var splitPath = context.Request.Path.Value.Split("/");
            var path = splitPath[1];
                        
            if (context.Request.Method == "GET" &&
                // Exact path match or Relative path match
                (_cache.TryGetValue(requestPath, out entry) || _cache.TryGetValue("/" + path, out entry)))                              
            {
                string destination = entry.UseRelative ? GetRelativeUrl(requestPath, entry.RedirectUrl, entry.TargetUrl) : entry.TargetUrl;
                context.Response.Redirect(destination, entry.RedirectType == 301);
                return;
            }            
                
            await _next(context);

        }

        private string GetRelativeUrl(string fullUrl, string redirectUrl, string targetUrl)
        {
            return fullUrl.Replace(redirectUrl, targetUrl);
        }


        private async Task RefreshCacheAsync()
        {
            try
            {                
                HttpResponseMessage response;

                using (var httpClient = new HttpClient())
                {
                    response = await httpClient.GetAsync(_options.ApiUrl);
                }

                if (!response.IsSuccessStatusCode)
                {
                    _logger.LogError($"Failed to refresh cache: {response.StatusCode} - {response.ReasonPhrase}");
                    return;
                }

                string content = await response.Content.ReadAsStringAsync();
                IEnumerable<RedirectEntry> entries = JsonConvert.DeserializeObject<IEnumerable<RedirectEntry>>(content);

                foreach (RedirectEntry entry in entries)
                {
                    string key = entry.RedirectUrl;                    
                    _cache[key] = entry;
                }

                _logger.LogInformation($"Cache refreshed with {entries.Count()} entries");
            }
            catch (Exception ex)
            {
                _logger.LogError($"Failed to refresh cache: {ex.Message}");
            }
        }

        public void Dispose()
        {
            _timer.Dispose();            
        }
    }

}