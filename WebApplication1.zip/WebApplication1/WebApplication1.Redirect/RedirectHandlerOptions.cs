﻿namespace WebApplication1;

public class RedirectHandlerOptions
{
    public string ApiUrl { get; set; } = "https://localhost:7191/Redirect/api/GetRedirectUrls";
    public TimeSpan CacheDuration { get; set; } = TimeSpan.FromMinutes(2);
 
}
